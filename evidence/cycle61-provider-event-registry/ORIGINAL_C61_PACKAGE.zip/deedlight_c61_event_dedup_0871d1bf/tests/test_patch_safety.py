"""Static safety invariants for the proposed PG patch; not PG parse/execution."""
from pathlib import Path
import re
import unittest

SQL = (Path(__file__).resolve().parents[1] / "patch" / "PROPOSED_POST_028_provider_event_registry.sql").read_text()

class PatchSafetyTests(unittest.TestCase):
    def test_one_provider_event_primary_key(self):
        self.assertIn('PRIMARY KEY (provider, event_id)', SQL)
    def test_provider_message_ids_uniquely_indexed(self):
        self.assertIn('CREATE UNIQUE INDEX delivery_ledger_provider_result_unique_c61', SQL)
        self.assertIn('ON public.delivery_ledger (provider_result_id)', SQL)

    def test_one_registry_physical_table(self):
        self.assertEqual(1, len(re.findall(r'CREATE TABLE deedlight_event_private\.provider_event_registry', SQL)))
    def test_views_for_each_state(self):
        for state in ('pending','processed','identity_conflict'):
            self.assertIn(f"WHERE state = '{state}'", SQL)
    def test_new_registry_disabled(self):
        self.assertIn('accepting_new_events boolean NOT NULL DEFAULT false', SQL)
        self.assertIn('Provider registry historical reconciliation incomplete', SQL)
    def test_no_activation_rpc(self):
        self.assertNotRegex(SQL, r'CREATE FUNCTION .*activate')
    def test_unique_conflict_serialization(self):
        self.assertIn('ON CONFLICT (provider, event_id) DO NOTHING', SQL)
        self.assertIn('FOR UPDATE', SQL)
    def test_conflict_quarantine_durable(self):
        self.assertIn("'payload_or_metadata_conflict'", SQL)
        self.assertIn("'ambiguous_provider_delivery'", SQL)
        self.assertIn("state = 'identity_conflict'", SQL)
    def test_no_automatic_unsuppression(self):
        self.assertNotRegex(SQL, r'(?im)^\s*DELETE\s+FROM\s+[^\n]*suppres')
        self.assertNotIn('unsuppress', SQL.lower().split('create function')[1].split('revoke all')[0])
    def test_browser_rpc_revoke_and_service_only_execute(self):
        for signature in [
            'public.deedlight_reserve_provider_event(text,text,bytea,text,text)',
            'public.deedlight_bind_provider_event(text,text)',
            'public.deedlight_process_nonsuppressing_event(text,text)',
        ]:
            self.assertIn('REVOKE ALL ON FUNCTION '+signature, SQL)
            self.assertIn('GRANT EXECUTE ON FUNCTION '+signature, SQL)
        self.assertIn('FROM PUBLIC, anon, authenticated;', SQL)
        self.assertIn('TO service_role;', SQL)
    def test_service_role_lacks_private_dml(self):
        self.assertIn('REVOKE ALL ON ALL TABLES IN SCHEMA deedlight_event_private', SQL)
        self.assertIn('FROM PUBLIC, anon, authenticated, service_role;', SQL)
    def test_fixed_search_path_for_security_definer(self):
        self.assertEqual(3, SQL.count('SECURITY DEFINER'))
        self.assertEqual(3, SQL.count('SET search_path = pg_catalog, pg_temp'))
    def test_only_database_ledger_association(self):
        self.assertIn('FROM public.delivery_ledger dl', SQL)
        self.assertIn('WHERE dl.provider_result_id = v_record.provider_message_id', SQL)
        self.assertNotIn('p_recipient_fingerprint', SQL)
        self.assertNotIn('p_user_id', SQL)
    def test_processed_event_reverifies_ledger_mapping(self):
        self.assertIn('AND dl.provider_result_id = v_record.provider_message_id', SQL)
        self.assertIn('FOR SHARE OF dl;', SQL)

    def test_operator_control_row_locks(self):
        self.assertEqual(5, SQL.count('FOR SHARE'))
    def test_proposed_patch_has_explicit_transaction(self):
        self.assertTrue(SQL.lstrip().startswith('--'))
        self.assertRegex(SQL, r'(?m)^BEGIN;$')
        self.assertRegex(SQL, r'(?m)^COMMIT;$')
    def test_no_prod_migration_push_or_deployment(self):
        self.assertNotIn('db push', SQL.lower().split('begin;')[1])
        self.assertNotIn('send_email(', SQL.lower())

if __name__ == '__main__':
    unittest.main()
