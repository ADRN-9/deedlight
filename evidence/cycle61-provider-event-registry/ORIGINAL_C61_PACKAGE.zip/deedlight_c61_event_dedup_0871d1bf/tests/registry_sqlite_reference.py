"""Isolated SQLite cross-state uniqueness reference, NOT PostgreSQL verification."""
from __future__ import annotations

import re
import sqlite3
from contextlib import contextmanager, closing
from dataclasses import dataclass
from pathlib import Path

EVENT_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,254}$", re.ASCII)
EVENT_TYPE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$", re.ASCII)


class Closed(Exception):
    pass


@dataclass(frozen=True)
class Event:
    provider: str
    event_id: str
    payload_sha256: bytes
    event_type: str
    provider_message_id: str | None = None


SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE control (
  singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
  enabled INTEGER NOT NULL CHECK (enabled IN (0, 1)),
  reconciled TEXT
);
INSERT INTO control VALUES (1, 0, NULL);
CREATE TABLE registry (
  provider TEXT NOT NULL CHECK (provider = 'resend'),
  event_id TEXT NOT NULL,
  digest BLOB NOT NULL CHECK(length(digest) = 32),
  event_type TEXT NOT NULL,
  provider_message_id TEXT,
  state TEXT NOT NULL DEFAULT 'pending'
      CHECK(state IN ('pending', 'processed', 'identity_conflict')),
  bound_delivery_id TEXT,
  PRIMARY KEY(provider, event_id)
);
CREATE TABLE conflicts (
  provider TEXT NOT NULL,
  event_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  digest BLOB NOT NULL,
  PRIMARY KEY(provider, event_id, reason, digest),
  FOREIGN KEY(provider, event_id) REFERENCES registry(provider, event_id)
);
CREATE TABLE ledger (id TEXT PRIMARY KEY, provider_result_id TEXT UNIQUE);
CREATE TABLE suppressions (recipient_key TEXT PRIMARY KEY, reason TEXT NOT NULL);
CREATE TABLE historical_sources (
  source_table TEXT NOT NULL, provider TEXT NOT NULL, event_id TEXT NOT NULL,
  digest BLOB NOT NULL, PRIMARY KEY(source_table, provider, event_id)
);
"""


class Registry:
    def __init__(self, path: Path):
        self.path = path

    @classmethod
    def initialize(cls, path: Path) -> "Registry":
        with closing(sqlite3.connect(path)) as db:
            db.executescript(SCHEMA)
            db.execute("PRAGMA journal_mode=WAL")
        return cls(path)

    @contextmanager
    def db(self):
        db = sqlite3.connect(self.path, timeout=20, isolation_level=None)
        try:
            db.execute("PRAGMA foreign_keys=ON")
            db.execute("PRAGMA busy_timeout=20000")
            yield db
            if db.in_transaction:
                db.commit()
        except BaseException:
            if db.in_transaction:
                db.rollback()
            raise
        finally:
            db.close()

    def enable_for_synthetic_test(self):
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            bad = db.execute("""
                SELECT provider,event_id FROM historical_sources
                GROUP BY provider,event_id HAVING count(*)>1
            """).fetchall()
            if bad:
                db.execute("ROLLBACK")
                raise Closed("historical event IDs require explicit reconciliation")
            if db.execute("SELECT 1 FROM historical_sources LIMIT 1").fetchone():
                db.execute("ROLLBACK")
                raise Closed("historical rows remain unimported; activation forbidden")
            db.execute("UPDATE control SET enabled=1,reconciled='synthetic-confirmed' WHERE singleton=1")
            db.execute("COMMIT")

    @staticmethod
    def validate(event: Event):
        if (event.provider != "resend"
            or not isinstance(event.event_id, str)
            or not EVENT_ID.fullmatch(event.event_id)
            or not isinstance(event.event_type, str)
            or not EVENT_TYPE.fullmatch(event.event_type)
            or not isinstance(event.payload_sha256, bytes)
            or len(event.payload_sha256) != 32
            or (event.provider_message_id is not None and
                (not isinstance(event.provider_message_id, str) or
                 len(event.provider_message_id) not in range(1, 256) or
                 any(ord(c) < 32 or ord(c) == 127 for c in event.provider_message_id)))):
            raise Closed("invalid verified-event metadata")

    @staticmethod
    def must_be_enabled(db):
        if db.execute("SELECT enabled,reconciled FROM control WHERE singleton=1").fetchone() != (1, "synthetic-confirmed"):
            raise Closed("historical reconciliation not complete")

    def reserve(self, event: Event, *, inject_error: bool = False) -> str:
        self.validate(event)
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                self.must_be_enabled(db)
                if inject_error:
                    db.execute("INSERT INTO nonexistent_provider_table VALUES (1)")
                written = db.execute("""
                  INSERT INTO registry(provider,event_id,digest,event_type,provider_message_id)
                  VALUES(?,?,?,?,?) ON CONFLICT(provider,event_id) DO NOTHING
                """, (event.provider, event.event_id, event.payload_sha256,
                      event.event_type, event.provider_message_id)).rowcount
                if written == 1:
                    db.execute("COMMIT")
                    return "NEW_PENDING"
                row = db.execute("""
                  SELECT digest,event_type,provider_message_id,state
                  FROM registry WHERE provider=? AND event_id=?
                """, (event.provider, event.event_id)).fetchone()
                if row is None:
                    raise Closed("uniqueness conflict invisible")
                digest, event_type, message_id, state = row
                if (digest, event_type, message_id) != (
                    event.payload_sha256, event.event_type, event.provider_message_id):
                    db.execute("""
                      INSERT INTO conflicts(provider,event_id,reason,digest)
                      VALUES(?,?,'payload_or_metadata_conflict',?)
                      ON CONFLICT DO NOTHING
                    """, (event.provider, event.event_id, event.payload_sha256))
                    db.execute("""
                      UPDATE registry SET state='identity_conflict'
                      WHERE provider=? AND event_id=?
                    """, (event.provider, event.event_id))
                    status = "IDENTITY_CONFLICT"
                else:
                    status = {"pending":"DUPLICATE_PENDING", "processed":"DUPLICATE_PROCESSED",
                              "identity_conflict":"QUARANTINED"}[state]
                db.execute("COMMIT")
                return status
            except BaseException:
                db.execute("ROLLBACK")
                raise

    def bind(self, provider: str, event_id: str) -> str:
        if provider != "resend" or not isinstance(event_id, str) or not EVENT_ID.fullmatch(event_id):
            raise Closed("invalid provider/event ID")
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                self.must_be_enabled(db)
                row = db.execute("""
                  SELECT digest,provider_message_id,bound_delivery_id,state
                  FROM registry WHERE provider=? AND event_id=?
                """, (provider, event_id)).fetchone()
                if not row:
                    raise Closed("unknown event")
                digest, msg, bound, state = row
                if state == "identity_conflict":
                    status = "QUARANTINED"
                elif state == "processed":
                    status = "DUPLICATE_PROCESSED"
                elif msg is None:
                    status = "PENDING_UNMATCHED"
                else:
                    ids = [r[0] for r in db.execute(
                        "SELECT id FROM ledger WHERE provider_result_id=? ORDER BY id LIMIT 2", (msg,))]
                    if not ids:
                        status = "PENDING_UNMATCHED"
                    elif len(ids) > 1 or (bound is not None and bound != ids[0]):
                        reason = ("ambiguous_provider_delivery" if len(ids)>1
                                  else "changed_provider_delivery_binding")
                        db.execute("INSERT INTO conflicts VALUES(?,?,?,?) ON CONFLICT DO NOTHING",
                                   (provider,event_id,reason,digest))
                        db.execute("UPDATE registry SET state='identity_conflict' WHERE provider=? AND event_id=?",
                                   (provider,event_id))
                        status = "IDENTITY_CONFLICT"
                    else:
                        db.execute("UPDATE registry SET bound_delivery_id=? WHERE provider=? AND event_id=?",
                                   (ids[0],provider,event_id))
                        status = "BOUND_PENDING"
                db.execute("COMMIT")
                return status
            except BaseException:
                db.execute("ROLLBACK")
                raise

    def process_nonsuppressing(self, provider: str, event_id: str) -> str:
        if provider != "resend" or not isinstance(event_id, str) or not EVENT_ID.fullmatch(event_id):
            raise Closed("invalid provider/event ID")
        with self.db() as db:
            db.execute("BEGIN IMMEDIATE")
            try:
                self.must_be_enabled(db)
                row = db.execute("""
                  SELECT state,event_type,bound_delivery_id FROM registry
                  WHERE provider=? AND event_id=?
                """, (provider,event_id)).fetchone()
                if not row:
                    raise Closed("unknown event")
                state, kind, bound = row
                if state == "identity_conflict": status = "QUARANTINED"
                elif state == "processed": status = "DUPLICATE_PROCESSED"
                elif kind not in {"email.delivered", "email.sent"}:
                    raise Closed("suppression-sensitive event requires approved atomic lifecycle")
                elif bound is None: status = "PENDING_UNMATCHED"
                elif not db.execute("SELECT 1 FROM ledger WHERE id=? AND provider_result_id=?",
                                    (bound, db.execute("SELECT provider_message_id FROM registry WHERE provider=? AND event_id=?",
                                                       (provider,event_id)).fetchone()[0])).fetchone():
                    digest = db.execute("SELECT digest FROM registry WHERE provider=? AND event_id=?",
                                        (provider,event_id)).fetchone()[0]
                    db.execute("INSERT INTO conflicts VALUES(?,?,'changed_provider_delivery_binding',?) ON CONFLICT DO NOTHING",
                               (provider,event_id,digest))
                    db.execute("UPDATE registry SET state='identity_conflict' WHERE provider=? AND event_id=?",
                               (provider,event_id))
                    status = "IDENTITY_CONFLICT"
                else:
                    db.execute("UPDATE registry SET state='processed' WHERE provider=? AND event_id=?",
                               (provider,event_id))
                    status = "PROCESSED"
                db.execute("COMMIT")
                return status
            except BaseException:
                db.execute("ROLLBACK")
                raise
