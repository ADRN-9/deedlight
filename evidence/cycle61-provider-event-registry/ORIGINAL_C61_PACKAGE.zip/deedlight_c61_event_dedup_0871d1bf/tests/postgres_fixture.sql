\set ON_ERROR_STOP on
\echo 'DeedLight C61: isolated PostgreSQL 16 fixture, synthetic data only'
DO $version$
BEGIN
  IF current_setting('server_version_num')::integer / 10000 <> 16 THEN
    RAISE EXCEPTION 'Requires disposable PostgreSQL 16';
  END IF;
  IF to_regrole('anon') IS NULL THEN EXECUTE 'CREATE ROLE anon NOLOGIN'; END IF;
  IF to_regrole('authenticated') IS NULL THEN EXECUTE 'CREATE ROLE authenticated NOLOGIN'; END IF;
  IF to_regrole('service_role') IS NULL THEN EXECUTE 'CREATE ROLE service_role NOLOGIN'; END IF;
END
$version$;
CREATE TABLE public.delivery_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  state text NOT NULL DEFAULT 'sent',
  provider_result_id text
);
CREATE FUNCTION public.begin_delivery_transport(uuid,uuid,text)
  RETURNS timestamptz LANGUAGE sql AS $$ SELECT clock_timestamp() $$;
-- Synthetic prerequisites solely for registry-only tests; do not represent 024 execution.
\i /tmp/deedlight_c61_migration.sql

-- Fail closed until historical event table reconciliation.
DO $inactive$
BEGIN
  BEGIN
    PERFORM public.deedlight_reserve_provider_event(
      'resend','evt_preflight',decode(repeat('01',32),'hex'),'email.bounced','mail_001');
    RAISE EXCEPTION 'ERROR: unactivated registry accepted an event';
  EXCEPTION WHEN SQLSTATE '55000' THEN NULL;
  END;
END
$inactive$;

-- Synthetic test ONLY: the disposable instance has no actual 025-028 history.
UPDATE deedlight_event_private.registry_control
SET accepting_new_events=true, reconciled_at=clock_timestamp(),
    reconciled_evidence='synthetic-empty-legacy-tables-reviewed';

DO $tests$
DECLARE
  v_digest bytea := decode(repeat('01',32),'hex');
  v_other bytea := decode(repeat('02',32),'hex');
  v_status text;
  v_delivery_id uuid;
  v_count integer;
BEGIN
  v_status := public.deedlight_reserve_provider_event('resend','evt_a',v_digest,'email.bounced','mail_a');
  IF v_status <> 'NEW_PENDING' THEN RAISE EXCEPTION 'new failed %',v_status; END IF;
  v_status := public.deedlight_reserve_provider_event('resend','evt_a',v_digest,'email.bounced','mail_a');
  IF v_status <> 'DUPLICATE_PENDING' THEN RAISE EXCEPTION 'pending duplicate failed %',v_status; END IF;
  SELECT count(*) INTO v_count FROM deedlight_event_private.provider_event_registry
     WHERE provider='resend' AND event_id='evt_a';
  IF v_count <> 1 THEN RAISE EXCEPTION 'duplicate event ID accepted'; END IF;

  v_status := public.deedlight_reserve_provider_event('resend','evt_a',v_other,'email.bounced','mail_a');
  IF v_status <> 'IDENTITY_CONFLICT' THEN RAISE EXCEPTION 'conflict not quarantined %',v_status; END IF;
  v_status := public.deedlight_reserve_provider_event('resend','evt_a',v_digest,'email.bounced','mail_a');
  IF v_status <> 'QUARANTINED' THEN RAISE EXCEPTION 'quarantine reopened %',v_status; END IF;
  SELECT count(*) INTO v_count FROM deedlight_event_private.provider_event_quarantine
     WHERE provider='resend' AND event_id='evt_a';
  IF v_count <> 1 THEN RAISE EXCEPTION 'conflict evidence lost'; END IF;

  v_status := public.deedlight_reserve_provider_event('resend','evt_b',v_digest,'email.complained','mail_b');
  IF v_status <> 'NEW_PENDING' THEN RAISE EXCEPTION 'complaint new failed'; END IF;
  v_status := public.deedlight_bind_provider_event('resend','evt_b');
  IF v_status <> 'PENDING_UNMATCHED' THEN RAISE EXCEPTION 'premature binding'; END IF;
  INSERT INTO public.delivery_ledger(provider_result_id) VALUES ('mail_b') RETURNING id INTO v_delivery_id;
  v_status := public.deedlight_bind_provider_event('resend','evt_b');
  IF v_status <> 'BOUND_PENDING' THEN RAISE EXCEPTION 'binding failed %',v_status; END IF;
  IF NOT EXISTS (
    SELECT 1 FROM deedlight_event_private.provider_event_registry
    WHERE event_id='evt_b' AND bound_delivery_id=v_delivery_id AND state='pending'
  ) THEN RAISE EXCEPTION 'processed without suppression or wrong database binding'; END IF;

  BEGIN
    PERFORM public.deedlight_process_nonsuppressing_event('resend','evt_b');
    RAISE EXCEPTION 'complaint promoted without suppression';
  EXCEPTION WHEN SQLSTATE '55000' THEN NULL;
  END;

  v_status := public.deedlight_reserve_provider_event('resend','evt_c',v_digest,'email.delivered','mail_c');
  INSERT INTO public.delivery_ledger(provider_result_id) VALUES ('mail_c');
  IF public.deedlight_bind_provider_event('resend','evt_c') <> 'BOUND_PENDING' THEN
    RAISE EXCEPTION 'delivered event not bound';
  END IF;
  IF public.deedlight_process_nonsuppressing_event('resend','evt_c') <> 'PROCESSED' THEN
    RAISE EXCEPTION 'delivered event not processed';
  END IF;
  v_status := public.deedlight_reserve_provider_event('resend','evt_c',v_digest,'email.delivered','mail_c');
  IF v_status <> 'DUPLICATE_PROCESSED' THEN RAISE EXCEPTION 'processed replay accepted'; END IF;

  v_status := public.deedlight_reserve_provider_event('resend','evt_ambiguous',v_digest,'email.bounced','mail_ambiguous');
  INSERT INTO public.delivery_ledger(provider_result_id) VALUES ('mail_ambiguous');
  BEGIN
    INSERT INTO public.delivery_ledger(provider_result_id) VALUES ('mail_ambiguous');
    RAISE EXCEPTION 'duplicate provider-message ID accepted';
  EXCEPTION WHEN unique_violation THEN NULL;
  END;
  IF public.deedlight_bind_provider_event('resend','evt_ambiguous') <> 'BOUND_PENDING' THEN
    RAISE EXCEPTION 'unique provider message association did not bind';
  END IF;
  UPDATE public.delivery_ledger SET provider_result_id='replaced_message'
    WHERE provider_result_id='mail_ambiguous';
  INSERT INTO public.delivery_ledger(provider_result_id) VALUES ('mail_ambiguous');
  v_status := public.deedlight_bind_provider_event('resend','evt_ambiguous');
  IF v_status <> 'IDENTITY_CONFLICT' THEN RAISE EXCEPTION 'changed binding was accepted'; END IF;
  IF (SELECT state FROM deedlight_event_private.provider_event_registry WHERE event_id='evt_ambiguous')
      <> 'identity_conflict' THEN RAISE EXCEPTION 'quarantine state missing'; END IF;

  BEGIN
    PERFORM public.deedlight_reserve_provider_event('resend','bad event',v_digest,'email.bounced','mail_a');
    RAISE EXCEPTION 'invalid ID incorrectly accepted';
  EXCEPTION WHEN SQLSTATE '22023' THEN NULL;
  END;
  BEGIN
    PERFORM public.deedlight_reserve_provider_event('resend','evt_wrong_digest',decode('0a','hex'),'email.bounced','mail_a');
    RAISE EXCEPTION 'invalid digest incorrectly accepted';
  EXCEPTION WHEN SQLSTATE '22023' THEN NULL;
  END;
  BEGIN
    PERFORM public.deedlight_reserve_provider_event('unsupported','evt_wrong_provider',v_digest,'email.bounced','mail_a');
    RAISE EXCEPTION 'unsupported provider incorrectly accepted';
  EXCEPTION WHEN SQLSTATE '22023' THEN NULL;
  END;
END
$tests$;

DO $privileges$
BEGIN
  IF has_schema_privilege('anon','deedlight_event_private','USAGE')
    OR has_schema_privilege('authenticated','deedlight_event_private','USAGE')
    OR has_table_privilege('anon','deedlight_event_private.provider_event_registry','SELECT')
    OR has_table_privilege('authenticated','deedlight_event_private.provider_event_registry','INSERT')
    OR has_table_privilege('service_role','deedlight_event_private.provider_event_registry','INSERT')
    OR has_function_privilege('anon','public.deedlight_reserve_provider_event(text,text,bytea,text,text)','EXECUTE')
    OR has_function_privilege('authenticated','public.deedlight_bind_provider_event(text,text)','EXECUTE')
    OR has_function_privilege('anon','public.deedlight_process_nonsuppressing_event(text,text)','EXECUTE')
    OR NOT has_function_privilege('service_role','public.deedlight_process_nonsuppressing_event(text,text)','EXECUTE')
    OR NOT has_function_privilege('service_role','public.deedlight_reserve_provider_event(text,text,bytea,text,text)','EXECUTE')
    OR NOT has_function_privilege('service_role','public.deedlight_bind_provider_event(text,text)','EXECUTE')
  THEN RAISE EXCEPTION 'Unexpected browser or server role privileges';
  END IF;
END
$privileges$;
\echo 'DISPOSABLE POSTGRESQL REGISTRY FIXTURE PASS (not Production)'
