# Source provenance / recovery limits

- DeedLight repo `ADRN-9/deedlight`; historical `main`: `ce82b3fdf1a73510de70e3729a487d4ae00e66e3`; historical combined delivery/audit candidate: `4a403eee5fe4fc45e3decde988dc5e488cdf3b81`.
- Cycle 61 evidence commit `80fed7f0b3e07c3c9ee0cf0fdb0675559a54b9bd`; recovered `ORIGINAL_C61_UNCHANGED.sql` SHA-256 `ed0dc53204c91b6171bc12de40929df6f54bae24e78716f0072d69593e008672`.
- Cycle 65 evidence commit `cf41a564ff1810aa1c8a592dfb147e5141ec963c`; recovered `ORIGINAL_C65_UNCHANGED.sql` SHA-256 `ba8267aad42134ae704ff4712054e4fc6532d6f85d5e5b5c622c4bb963d96566`.
- Missing original C47 consolidated remediation archive: expected SHA-256 `fe0bc550997887c31ae43851b05883cc72181eb2af7419fdb05a59aeb3e23fdf` — **UNAVAILABLE/UNVERIFIED**.
- Missing C48 database-audit corrections archive: expected SHA-256 `f79eab77a271e82f281f236b493aeeff972424ce7d0b50a4e0e7d2f200b8271a` — **UNAVAILABLE/UNVERIFIED**.
- No authentic 025–028 migration SQL exists in the mounted local files or pinned Git tree. Exact function signatures/table layouts beyond the two named RPC families and `public.delivery_provider_identity_conflicts` are **UNKNOWN**; the fixture is explicitly synthetic.
- Current ownership: no exclusive shared application-source clearance. This is a new isolated local artifact only, not a shared commit.
