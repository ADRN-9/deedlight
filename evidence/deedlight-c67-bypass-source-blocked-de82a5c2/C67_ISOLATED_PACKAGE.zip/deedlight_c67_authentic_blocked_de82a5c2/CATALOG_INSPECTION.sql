-- READ-ONLY metadata. Approved disposable PostgreSQL instance with authentic
-- migrations 025-028 ONLY; never query actual user event rows.
\set ON_ERROR_STOP on
SELECT n.nspname AS schema_name, p.proname AS function_name,
       p.oid::regprocedure::text AS signature,
       pg_get_userbyid(p.proowner) AS function_owner,
       p.prosecdef AS security_definer,
       p.proconfig::text[] AS configuration,
       md5(p.prosrc) AS source_md5,
       has_function_privilege('service_role',p.oid,'EXECUTE') AS service_execute,
       has_function_privilege('anon',p.oid,'EXECUTE') AS anonymous_execute,
       has_function_privilege('authenticated',p.oid,'EXECUTE') AS signed_in_execute,
       (SELECT count(*) FROM pg_depend d
        WHERE d.refclassid='pg_proc'::regclass AND d.refobjid=p.oid) AS dependent_object_count
FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
WHERE n.nspname IN ('public','delivery_private','deedlight_delivery_private')
  AND (p.proname IN ('record_resend_webhook_event',
                     'record_resend_webhook_event_identity_bound')
       OR p.proname ILIKE '%webhook%' OR p.proname ILIKE '%provider%event%')
ORDER BY n.nspname,p.proname,signature;

-- Candidate table inventory: inspect *all* tables in the relevant schema,
-- including those whose names or columns do not mention events.
SELECT n.nspname AS schema_name, c.relname AS relation_name,
       c.relkind AS relation_kind,pg_get_userbyid(c.relowner) AS relation_owner,
       c.relrowsecurity AS rls_enabled,c.relforcerowsecurity AS rls_forced,
       has_table_privilege('service_role',c.oid,'INSERT') AS service_insert,
       has_table_privilege('anon',c.oid,'INSERT') AS anonymous_insert,
       has_table_privilege('authenticated',c.oid,'INSERT') AS signed_in_insert,
       array_agg(a.attname::text ORDER BY a.attnum) FILTER (WHERE a.attnum>0 AND NOT a.attisdropped) AS column_names
FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
LEFT JOIN pg_attribute a ON a.attrelid=c.oid
WHERE n.nspname IN ('public','delivery_private','deedlight_delivery_private')
  AND c.relkind IN ('r','p')
GROUP BY n.nspname,c.relname,c.relkind,c.relowner,c.relrowsecurity,c.relforcerowsecurity,c.oid
ORDER BY n.nspname,c.relname;

-- Trigger provenance for the same schemas; never select row contents.
SELECT n.nspname,c.relname,t.tgname,t.tgenabled,
       t.tgfoid::regprocedure AS trigger_function
FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid
JOIN pg_namespace n ON n.oid=c.relnamespace
WHERE NOT t.tgisinternal
  AND n.nspname IN ('public','delivery_private','deedlight_delivery_private')
ORDER BY n.nspname,c.relname,t.tgname;
