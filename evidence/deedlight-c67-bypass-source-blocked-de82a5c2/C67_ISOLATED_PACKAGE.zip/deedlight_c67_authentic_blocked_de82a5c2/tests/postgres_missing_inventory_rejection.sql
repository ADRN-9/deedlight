\set ON_ERROR_STOP on
-- Use a separate disposable DB after running fixture_synthetic_legacy_025_028.sql;
-- intentionally DROP the approved temp table before the C67 migration.
\ir fixture_synthetic_legacy_025_028.sql
DROP TABLE pg_temp.c67_reviewed_event_tables;
-- EXPECTS failure SQLSTATE 55000; run with psql -v ON_ERROR_STOP=1 and assert
-- nonzero status, then verify c67_legacy_veto_inventory does not exist.
\ir ../patch/202611140031_c67_closed_world_legacy_webhook_hard_stop.sql
