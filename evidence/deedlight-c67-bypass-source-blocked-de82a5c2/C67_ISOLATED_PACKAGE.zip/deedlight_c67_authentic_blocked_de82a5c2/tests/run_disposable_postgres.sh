#!/usr/bin/env bash
set -euo pipefail
set +x
# SYNTHETIC ONLY. Requires Docker+PostgreSQL 16 in an approved disposable host.
if [[ -z "${DEEDLIGHT_C67_DISPOSABLE_APPROVED:-}" || "${DEEDLIGHT_C67_DISPOSABLE_APPROVED}" != 'true' ]]; then
  echo 'Explicit disposable PostgreSQL approval required' >&2; exit 77
fi
for name in SUPABASE_PROJECT_REF SUPABASE_DB_PASSWORD DATABASE_URL PGPASSFILE PGHOST PGPORT PGDATABASE RESEND_API_KEY; do
  if [[ -n "${!name:-}" ]]; then echo "Forbidden external target/provider variable: ${name}" >&2; exit 77; fi
done
for bin in docker; do command -v "$bin" >/dev/null || { echo 'Docker unavailable' >&2; exit 77; }; done
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
container="deedlight-c67-disposable-$$"
cleanup(){ docker rm -f "$container" >/dev/null 2>&1 || :; }
trap cleanup EXIT
docker run -d --rm --name "$container" -e POSTGRES_PASSWORD=test_only_not_a_secret -e POSTGRES_DB=c67_test postgres:16 >/dev/null
for i in {1..40}; do
  if docker exec "$container" pg_isready -U postgres -d c67_test >/dev/null 2>&1; then break; fi
  sleep 1
done
# Avoid a host PostgreSQL connection entirely; stdin goes into a single container.
docker cp "$root" "$container:/tmp/deedlight_c67"
docker exec -w /tmp/deedlight_c67/tests -e PGPASSWORD=test_only_not_a_secret "$container" \
  psql -X -v ON_ERROR_STOP=1 -U postgres -d c67_test -f postgres_synthetic_success.sql
# Negative path on a different fresh DB. Failure is required.
docker exec -e PGPASSWORD=test_only_not_a_secret "$container" \
  createdb -U postgres c67_negative
docker exec -w /tmp/deedlight_c67/tests -e PGPASSWORD=test_only_not_a_secret "$container" \
  psql -X -v ON_ERROR_STOP=0 -U postgres -d c67_negative \
  -f postgres_missing_inventory_rejection.sql > /tmp/deedlight-c67-negative-$$.log 2>&1 || :
if ! grep -q 'C67 missing verified registry/024/025-028 inventory or required roles' /tmp/deedlight-c67-negative-$$.log; then
  cat /tmp/deedlight-c67-negative-$$.log >&2
  rm -f /tmp/deedlight-c67-negative-$$.log
  echo 'Expected missing inventory was not rejected' >&2;exit 1
fi
rm -f /tmp/deedlight-c67-negative-$$.log
echo 'C67_DISPOSABLE_SYNTHETIC_PG_TEST_PASS'
