\set ON_ERROR_STOP on
-- When running under psql in a fresh PostgreSQL 16 database:
\ir fixture_synthetic_legacy_025_028.sql
\ir ../patch/202611140031_c67_closed_world_legacy_webhook_hard_stop.sql
DO $test$
DECLARE v_count integer;
BEGIN
  SELECT count(*) INTO v_count FROM deedlight_event_private.c67_retired_rpc_inventory;
  IF v_count<>3 THEN RAISE EXCEPTION 'Expected all three known base+wrapper overloads retired'; END IF;
  SELECT count(*) INTO v_count FROM deedlight_event_private.c67_legacy_veto_inventory;
  IF v_count<>3 THEN RAISE EXCEPTION 'Expected complete explicit three-table veto'; END IF;
  IF to_regprocedure('public.record_resend_webhook_event(text)') IS NOT NULL
     OR to_regprocedure('public.record_resend_webhook_event(text,text)') IS NOT NULL
     OR to_regprocedure('public.record_resend_webhook_event_identity_bound(text)') IS NOT NULL
  THEN RAISE EXCEPTION 'BYPASS: legacy RPC survived'; END IF;
  IF (SELECT accepting_new_events FROM deedlight_event_private.registry_control WHERE singleton)
     IS DISTINCT FROM false THEN RAISE EXCEPTION 'BYPASS: registry enabled'; END IF;
  IF has_function_privilege('service_role',
      'public.begin_delivery_transport(uuid,uuid,text)','EXECUTE')
  THEN RAISE EXCEPTION 'BYPASS: transport still allowed'; END IF;
  IF (SELECT count(*) FROM public.delivery_provider_events WHERE event_id='evt_old')<>1
    OR (SELECT count(*) FROM public.delivery_provider_events_pending WHERE event_id='evt_old')<>1
    OR (SELECT count(*) FROM public.delivery_provider_identity_conflicts WHERE event_id='evt_old')<>1
  THEN RAISE EXCEPTION 'Historical evidence was destroyed'; END IF;
  IF has_table_privilege('anon','public.delivery_provider_events','INSERT')
     OR has_table_privilege('authenticated','public.delivery_provider_identity_conflicts','INSERT')
     OR has_table_privilege('service_role','public.delivery_provider_events_pending','INSERT')
  THEN RAISE EXCEPTION 'BYPASS: direct DML privileges present'; END IF;
END $test$;
-- All four kinds of physical mutation must fail, including SECURITY DEFINER's
-- indirect DML path if another reviewed function were to retain it.
DO $test$
BEGIN
  BEGIN
    INSERT INTO public.delivery_provider_events VALUES ('resend','evt_dup','email.bounced');
    RAISE EXCEPTION 'BYPASS: insert accepted';
  EXCEPTION WHEN SQLSTATE '55000' THEN NULL; END;
  BEGIN
    UPDATE public.delivery_provider_identity_conflicts SET reason='forged';
    RAISE EXCEPTION 'BYPASS: update accepted';
  EXCEPTION WHEN SQLSTATE '55000' THEN NULL; END;
  BEGIN
    DELETE FROM public.delivery_provider_events_pending;
    RAISE EXCEPTION 'BYPASS: delete accepted';
  EXCEPTION WHEN SQLSTATE '55000' THEN NULL; END;
  BEGIN
    TRUNCATE public.delivery_provider_identity_conflicts;
    RAISE EXCEPTION 'BYPASS: truncate accepted';
  EXCEPTION WHEN SQLSTATE '55000' THEN NULL; END;
END $test$;
SELECT 'C67_SYNTHETIC_DISPOSABLE_PG_NEGATIVES_PASS' AS result;
