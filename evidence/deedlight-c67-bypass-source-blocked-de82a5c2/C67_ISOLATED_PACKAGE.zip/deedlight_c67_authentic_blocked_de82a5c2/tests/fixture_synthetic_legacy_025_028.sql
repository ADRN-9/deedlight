-- SYNTHETIC fixture. NOT the authentic migrations 025–028.
-- Run in a fresh disposable PostgreSQL 16 database only; never Production.
\set ON_ERROR_STOP on
CREATE ROLE anon NOLOGIN;
CREATE ROLE authenticated NOLOGIN;
CREATE ROLE service_role NOLOGIN;
CREATE SCHEMA deedlight_event_private;
REVOKE ALL ON SCHEMA deedlight_event_private FROM PUBLIC, anon, authenticated, service_role;
CREATE TABLE deedlight_event_private.registry_control (
  singleton boolean PRIMARY KEY, accepting_new_events boolean NOT NULL
);
INSERT INTO deedlight_event_private.registry_control VALUES (true,false);
CREATE TABLE deedlight_event_private.provider_event_registry (
  provider text, event_id text, PRIMARY KEY (provider,event_id)
);
CREATE TABLE deedlight_event_private.provider_event_quarantine (
  provider text, event_id text, PRIMARY KEY (provider,event_id)
);
CREATE FUNCTION public.deedlight_reserve_provider_event(text,text,bytea,text,text)
RETURNS text LANGUAGE sql SECURITY DEFINER SET search_path=pg_catalog
AS $$SELECT 'FIXTURE_ONLY'::text$$;
CREATE FUNCTION public.begin_delivery_transport(uuid,uuid,text)
RETURNS timestamptz LANGUAGE sql SECURITY DEFINER SET search_path=pg_catalog
AS $$SELECT pg_catalog.clock_timestamp()$$;
GRANT EXECUTE ON FUNCTION public.begin_delivery_transport(uuid,uuid,text) TO service_role;
CREATE TABLE public.delivery_provider_events (
  provider text NOT NULL,event_id text NOT NULL,kind text NOT NULL
);
CREATE TABLE public.delivery_provider_events_pending (
  provider text NOT NULL,event_id text NOT NULL,kind text NOT NULL
);
CREATE TABLE public.delivery_provider_identity_conflicts (
  provider text NOT NULL,event_id text NOT NULL,reason text NOT NULL
);
INSERT INTO public.delivery_provider_events VALUES ('resend','evt_old','email.delivered');
INSERT INTO public.delivery_provider_events_pending VALUES ('resend','evt_old','email.bounced');
INSERT INTO public.delivery_provider_identity_conflicts VALUES ('resend','evt_old','recipient_changed');
CREATE FUNCTION public.record_resend_webhook_event(p_event text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $$BEGIN
  INSERT INTO public.delivery_provider_events(provider,event_id,kind)
  VALUES ('resend',p_event,'email.delivered');
  RETURN true;
END$$;
CREATE FUNCTION public.record_resend_webhook_event(p_event text,p_kind text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $$BEGIN
  INSERT INTO public.delivery_provider_events(provider,event_id,kind)
  VALUES ('resend',p_event,p_kind);
  RETURN true;
END$$;
CREATE FUNCTION public.record_resend_webhook_event_identity_bound(p_event text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path=pg_catalog
AS $$BEGIN
  INSERT INTO public.delivery_provider_identity_conflicts(provider,event_id,reason)
  VALUES ('resend',p_event,'recipient_changed');
  RETURN true;
END$$;
GRANT EXECUTE ON FUNCTION public.record_resend_webhook_event(text) TO service_role;
GRANT EXECUTE ON FUNCTION public.record_resend_webhook_event(text,text) TO service_role;
GRANT EXECUTE ON FUNCTION public.record_resend_webhook_event_identity_bound(text) TO service_role;
GRANT INSERT,UPDATE,DELETE,TRUNCATE ON public.delivery_provider_events TO service_role;
GRANT INSERT,UPDATE,DELETE,TRUNCATE ON public.delivery_provider_events_pending TO service_role;
GRANT INSERT,UPDATE,DELETE,TRUNCATE ON public.delivery_provider_identity_conflicts TO service_role;

-- Source-review manifest for disposable tests ONLY. Authentic migration review
-- must replace this with independently verified exact table identifiers.
CREATE TEMP TABLE c67_reviewed_event_tables (
 schema_name text NOT NULL,table_name text NOT NULL,
 role_in_pipeline text NOT NULL,
 PRIMARY KEY (schema_name,table_name)
) ON COMMIT PRESERVE ROWS;
INSERT INTO pg_temp.c67_reviewed_event_tables VALUES
 ('public','delivery_provider_events','processed'),
 ('public','delivery_provider_events_pending','pending'),
 ('public','delivery_provider_identity_conflicts','identity_conflict');
