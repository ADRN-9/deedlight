-- Authentic 028 has already run: inject only a synthetic pending event and
-- recipient identity-conflict record to test immutable preservation.
-- This runs BEFORE C69; it has no provider sends and no real recipient data.
BEGIN;
INSERT INTO public.delivery_provider_pending_events
  (svix_event_id,provider_email_id,recipient_fingerprint,event_type,
   event_at,payload_sha256,suppression_reason)
VALUES ('msg_c69pending001','synthetic-provider-id',repeat('a',64),
  'email.bounced','2026-11-14T00:00:00Z',repeat('b',64),'permanent_bounce');
INSERT INTO public.delivery_provider_identity_conflicts
  (svix_event_id,provider_email_id,original_recipient_fingerprint,
   signed_recipient_fingerprint,payload_sha256)
VALUES ('msg_c69conflict001','synthetic-provider-id',repeat('a',64),
  repeat('c',64),repeat('d',64));
COMMIT;
