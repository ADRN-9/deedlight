\set ON_ERROR_STOP on
-- Synthetic fixture success conditions after applying C65 migration.
DO $$
DECLARE v_count integer;
BEGIN
  IF to_regprocedure('public.record_resend_webhook_event_identity_bound(text)') IS NOT NULL THEN
    RAISE EXCEPTION 'LEGACY_BYPASS: callable legacy RPC remains';
  END IF;
  IF (SELECT accepting_new_events FROM deedlight_event_private.registry_control WHERE singleton) IS DISTINCT FROM false THEN
    RAISE EXCEPTION 'REGISTRY_UNEXPECTEDLY_ENABLED';
  END IF;
  SELECT count(*) INTO v_count FROM deedlight_event_private.c65_legacy_veto_inventory;
  IF v_count<>3 THEN RAISE EXCEPTION 'EXPECTED THREE LEGACY VETOES, got %',v_count; END IF;
  SELECT count(*) INTO v_count FROM public.resend_webhook_events_processed WHERE event_id='evt_historical';
  IF v_count<>1 THEN RAISE EXCEPTION 'HISTORICAL PROCESSED ROW LOST'; END IF;
  SELECT count(*) INTO v_count FROM delivery_private.resend_webhook_events_pending WHERE event_id='evt_historical';
  IF v_count<>1 THEN RAISE EXCEPTION 'HISTORICAL PENDING ROW LOST'; END IF;
  IF has_function_privilege('anon', 'deedlight_event_private.c65_deny_legacy_event_write()', 'EXECUTE') THEN
    RAISE EXCEPTION 'BROWSER_PRIVILEGE_LEAK';
  END IF;
END$$;
-- Expect DML to fail, with no unacknowledged success.
DO $$
BEGIN
  BEGIN
    INSERT INTO public.resend_webhook_events_processed VALUES('resend','evt_replay');
    RAISE EXCEPTION 'VETO_BYPASS_PROCESSED';
  EXCEPTION WHEN SQLSTATE '55000' THEN NULL; END;
  BEGIN
    INSERT INTO delivery_private.resend_webhook_events_pending VALUES('resend','evt_replay');
    RAISE EXCEPTION 'VETO_BYPASS_PENDING';
  EXCEPTION WHEN SQLSTATE '55000' THEN NULL; END;
  BEGIN
    INSERT INTO delivery_private.provider_event_quarantine VALUES('resend','evt_replay');
    RAISE EXCEPTION 'VETO_BYPASS_CONFLICT';
  EXCEPTION WHEN SQLSTATE '55000' THEN NULL; END;
END$$;
SELECT 'C65_SYNTHETIC_NEGATIVE_ASSERTIONS_PASS';
