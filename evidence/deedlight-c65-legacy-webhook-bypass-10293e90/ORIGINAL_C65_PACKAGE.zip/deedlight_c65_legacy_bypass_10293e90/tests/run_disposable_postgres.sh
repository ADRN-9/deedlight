#!/usr/bin/env bash
set -euo pipefail
# Never uses a host, tunnel, shared database, credential or network.
[[ "${DEEDLIGHT_C65_DISPOSABLE_ACK:-}" == I_CONFIRM_SYNTHETIC_POSTGRES_ONLY ]] || { echo 'Missing disposable-only acknowledgment' >&2; exit 2; }
command -v docker >/dev/null || { echo 'PostgreSQL fixture NOT RUN: Docker unavailable' >&2; exit 2; }
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
name="deedlight_c65_synthetic_${BASHPID}"
cleanup(){ docker rm -f "$name" >/dev/null 2>&1 || true; }
trap cleanup EXIT
docker run -d --rm --network none --name "$name" -e POSTGRES_PASSWORD=synthetic-only-no-network postgres:16 >/dev/null
ready=false
for n in $(seq 1 45); do
  if docker exec "$name" pg_isready -U postgres -d postgres >/dev/null 2>&1; then ready=true; break; fi
  sleep 1
done
[[ "$ready" == true ]] || { echo 'Synthetic PostgreSQL failed to start' >&2; exit 1; }
docker cp "$root/tests/postgres_synthetic_setup.sql" "$name:/tmp/setup.sql"
docker cp "$root/patch/202611140030_close_legacy_webhook_acceptance.sql" "$name:/tmp/migration.sql"
docker cp "$root/tests/postgres_negative_assertions.sql" "$name:/tmp/assert.sql"
docker exec "$name" psql -v ON_ERROR_STOP=1 -U postgres -f /tmp/setup.sql >/dev/null
docker exec "$name" psql -v ON_ERROR_STOP=1 -U postgres -f /tmp/migration.sql >/dev/null
docker exec "$name" psql -v ON_ERROR_STOP=1 -U postgres -f /tmp/assert.sql
