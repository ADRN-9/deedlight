-- Disposable PostgreSQL 16 only: synthetic stand-in for unknown 025-029 source.
-- Never execute this fixture on an existing or Production database.
\set ON_ERROR_STOP on
CREATE ROLE anon NOLOGIN;
CREATE ROLE authenticated NOLOGIN;
CREATE ROLE service_role NOLOGIN;
CREATE SCHEMA delivery_private;
CREATE SCHEMA deedlight_event_private;
CREATE TABLE deedlight_event_private.registry_control (
  singleton boolean primary key, accepting_new_events boolean not null,
  reconciled_at timestamptz, reconciled_evidence text
);
INSERT INTO deedlight_event_private.registry_control VALUES (true,false,NULL,NULL);
CREATE TABLE deedlight_event_private.provider_event_registry (
  provider text NOT NULL, event_id text NOT NULL, state text NOT NULL,
  PRIMARY KEY(provider,event_id)
);
CREATE TABLE deedlight_event_private.provider_event_quarantine(
  provider text NOT NULL, event_id text NOT NULL,
  PRIMARY KEY(provider,event_id)
);
CREATE FUNCTION public.deedlight_reserve_provider_event(text,text,bytea,text,text)
RETURNS text LANGUAGE sql SECURITY DEFINER SET search_path=pg_catalog
AS $$SELECT 'SYNTHETIC_ONLY'::text$$;
CREATE TABLE public.resend_webhook_events_processed(provider text,event_id text);
CREATE TABLE delivery_private.resend_webhook_events_pending(provider text,event_id text);
CREATE TABLE delivery_private.provider_event_quarantine(provider text,event_id text);
-- Prove history is preserved even when duplicates existed in separate tables.
INSERT INTO public.resend_webhook_events_processed VALUES ('resend','evt_historical');
INSERT INTO delivery_private.resend_webhook_events_pending VALUES ('resend','evt_historical');
CREATE FUNCTION public.record_resend_webhook_event_identity_bound(p_id text)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog
AS $$BEGIN
  INSERT INTO public.resend_webhook_events_processed VALUES('resend',p_id);
  RETURN true;
END$$;
GRANT EXECUTE ON FUNCTION public.record_resend_webhook_event_identity_bound(text) TO service_role;
GRANT INSERT ON public.resend_webhook_events_processed TO service_role;
GRANT INSERT ON delivery_private.resend_webhook_events_pending TO service_role;
GRANT INSERT ON delivery_private.provider_event_quarantine TO service_role;
